/* MeviCar Next Sudoku: self-contained native app, no dependencies. */
(function(){
'use strict';
let game=null,root=null,boardObserver=null;
const store='mevicar-sudoku-v1';
function shuffled(a){return a.slice().sort(()=>Math.random()-.5)}
function solve(board,random=false){let best=-1,choices=null;for(let i=0;i<81;i++){if(board[i])continue;const used=new Set();const r=Math.floor(i/9),c=i%9;for(let j=0;j<9;j++){used.add(board[r*9+j]);used.add(board[j*9+c]);used.add(board[(Math.floor(r/3)*3+Math.floor(j/3))*9+Math.floor(c/3)*3+j%3])}const opts=(random?shuffled([1,2,3,4,5,6,7,8,9]):[1,2,3,4,5,6,7,8,9]).filter(n=>!used.has(n));if(!opts.length)return false;if(!choices||opts.length<choices.length){best=i;choices=opts;if(opts.length===1)break}}if(best<0)return true;for(const n of choices){board[best]=n;if(solve(board,random))return true}board[best]=0;return false}
function countSolutions(board,limit=2){let count=0;function visit(){if(count>=limit)return;let best=-1,opts=null;for(let i=0;i<81;i++){if(board[i])continue;const r=Math.floor(i/9),c=i%9,used=new Set();for(let j=0;j<9;j++){used.add(board[r*9+j]);used.add(board[j*9+c]);used.add(board[(Math.floor(r/3)*3+Math.floor(j/3))*9+Math.floor(c/3)*3+j%3])}const choices=[1,2,3,4,5,6,7,8,9].filter(n=>!used.has(n));if(!choices.length)return;if(!opts||choices.length<opts.length){best=i;opts=choices}}if(best<0){count++;return}for(const n of opts){board[best]=n;visit();if(count>=limit)break}board[best]=0}visit();return count}
function fresh(level){const solution=Array(81).fill(0);solve(solution,true);const puzzle=solution.slice(),targets={leicht:40,mittel:33,schwer:27};let clues=81;for(const i of shuffled(Array.from({length:81},(_,k)=>k))){if(clues<=targets[level])break;const saved=puzzle[i];puzzle[i]=0;if(countSolutions(puzzle.slice())!==1)puzzle[i]=saved;else clues--}game={level,solution,puzzle,values:puzzle.slice(),notes:{},selected:-1,mistakes:0,started:Date.now(),elapsed:0,finished:false,noteMode:false};save();draw()}
function save(){try{localStorage.setItem(store,JSON.stringify(game))}catch(e){}}
function restore(){try{const x=JSON.parse(localStorage.getItem(store));if(x&&Array.isArray(x.puzzle)&&x.puzzle.length===81&&Array.isArray(x.values)&&x.values.length===81&&Array.isArray(x.solution)&&x.solution.length===81){game=x;return}}catch(e){}fresh('mittel')}
function time(){const secs=(game.elapsed||0)+(game.finished?0:Math.floor((Date.now()-game.started)/1000));return Math.floor(secs/60)+':'+String(secs%60).padStart(2,'0')}
function markup(){
 return '<div class="sdk-root"><div class="sdk-content">'+
  '<div id="sdk-board" class="sdk-board" role="grid" aria-label="Sudoku Spielfeld"></div>'+
  '<div class="sdk-controls">'+
   '<header class="sdk-head"><select id="sdk-level" aria-label="Schwierigkeit">'+
    '<option value="leicht">Leicht</option><option value="mittel">Mittel</option><option value="schwer">Schwer</option>'+
   '</select><button id="sdk-new" type="button">Neu</button><span id="sdk-time">0:00</span></header>'+
   '<div class="sdk-control-pad"><div id="sdk-info" class="sdk-info"></div>'+
    '<div class="sdk-numbers">'+Array.from({length:9},(_,i)=>'<button type="button" data-num="'+(i+1)+'">'+(i+1)+'</button>').join('')+'</div>'+
    '<div class="sdk-actions"><button id="sdk-erase" type="button">Löschen</button>'+
     '<button id="sdk-note" type="button">Notizen</button><button id="sdk-hint" type="button">Tipp</button></div>'+
   '</div>'+
  '</div></div></div>';
}
function conflicts(i){const v=game.values[i];if(!v)return false;const r=Math.floor(i/9),c=i%9;for(let j=0;j<81;j++){if(j===i||game.values[j]!==v)continue;const rr=Math.floor(j/9),cc=j%9;if(rr===r||cc===c||(Math.floor(rr/3)===Math.floor(r/3)&&Math.floor(cc/3)===Math.floor(c/3)))return true}return false}
function draw(){if(!root||!game)return;const board=root.querySelector('#sdk-board');if(!board)return;board.innerHTML=game.values.map((n,i)=>{const selected=i===game.selected;const r=Math.floor(i/9),c=i%9;const related=game.selected>=0&&(Math.floor(game.selected/9)===r||game.selected%9===c||Math.floor(Math.floor(game.selected/9)/3)===Math.floor(r/3)&&Math.floor((game.selected%9)/3)===Math.floor(c/3));const same=n&&game.selected>=0&&n===game.values[game.selected];const classes=['sdk-cell',game.puzzle[i]?'sdk-fixed':'',selected?'sdk-selected':'',related?'sdk-related':'',same?'sdk-same':'',conflicts(i)?'sdk-conflict':'',c===2||c===5?'sdk-box-right':'',r===2||r===5?'sdk-box-bottom':''].filter(Boolean).join(' ');const notes=!n&&game.notes[i]?'<span class="sdk-notes">'+game.notes[i].map(v=>'<small>'+v+'</small>').join('')+'</span>':'';return '<button type="button" class="'+classes+'" data-cell="'+i+'" role="gridcell" aria-label="Zeile '+(r+1)+', Spalte '+(c+1)+(n?', '+n:'')+'">'+(n||notes)+'</button>'}).join('');root.querySelector('#sdk-level').value=game.level;root.querySelector('#sdk-time').textContent=time();root.querySelector('#sdk-note').classList.toggle('sdk-on',!!game.noteMode);root.querySelector('#sdk-info').textContent=game.finished?'Gelöst! Glückwunsch!':'Fehler: '+game.mistakes+' · '+game.values.filter(Boolean).length+'/81';}
function enter(n){if(game.finished||game.selected<0||game.puzzle[game.selected])return;const i=game.selected;if(game.noteMode&&n){const set=new Set(game.notes[i]||[]);if(set.has(n))set.delete(n);else set.add(n);game.notes[i]=[...set].sort();}else{if(n&&game.solution[i]!==n)game.mistakes++;game.values[i]=n;delete game.notes[i]}if(game.values.every((v,k)=>v===game.solution[k])){game.elapsed+=Math.floor((Date.now()-game.started)/1000);game.finished=true}save();draw()}
function onClick(e){const cell=e.target.closest('[data-cell]');if(cell){game.selected=Number(cell.dataset.cell);save();draw();return}const num=e.target.closest('[data-num]');if(num){enter(Number(num.dataset.num));return}const id=e.target.id;if(id==='sdk-erase')enter(0);if(id==='sdk-note'){game.noteMode=!game.noteMode;save();draw()}if(id==='sdk-hint'&&!game.finished){let i=game.selected;if(i<0||game.puzzle[i]||game.values[i]===game.solution[i])i=game.values.findIndex((v,k)=>v!==game.solution[k]&&!game.puzzle[k]);if(i>=0){game.selected=i;game.values[i]=game.solution[i];delete game.notes[i];if(game.values.every((v,k)=>v===game.solution[k])){game.elapsed+=Math.floor((Date.now()-game.started)/1000);game.finished=true}save();draw()}}if(id==='sdk-new')fresh(root.querySelector('#sdk-level').value)}
function onKey(e){if(!root||!root.isConnected||e.target.tagName==='SELECT')return;if(/^[1-9]$/.test(e.key)){enter(Number(e.key));e.preventDefault()}else if(e.key==='Backspace'||e.key==='Delete'){enter(0);e.preventDefault()}else if(['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)){const delta={ArrowUp:-9,ArrowDown:9,ArrowLeft:-1,ArrowRight:1}[e.key];game.selected=Math.max(0,Math.min(80,(game.selected<0?0:game.selected)+delta));save();draw();e.preventDefault()}}
function sizeBoard(){
 if(!root)return;
 const content=root.querySelector('.sdk-content'),board=root.querySelector('#sdk-board');
 const controls=root.querySelector('.sdk-controls');
 if(!content||!board||!controls)return;
 const style=typeof getComputedStyle==='function'?getComputedStyle(content):null;
 const gap=Number.parseFloat(style?.gap)||8;
 const vertical=style?.flexDirection==='column';
 const free=vertical?content.clientHeight-controls.offsetHeight-gap:
  content.clientWidth-controls.offsetWidth-gap;
 const size=Math.floor(Math.max(0,Math.min(
  vertical?content.clientWidth:content.clientHeight,free)));
 if(size>0)board.style.setProperty('--sdk-board-size',size+'px');
}
function mount(){
 const next=document.querySelector('.sdk-host');
 if(!next){unmount();return}
 unmount();root=next;root.innerHTML=markup();
 root.addEventListener('click',onClick);
 document.addEventListener('keydown',onKey);
 restore();draw();
 sizeBoard();
 if(typeof ResizeObserver!=='undefined'){
  boardObserver=new ResizeObserver(sizeBoard);
  boardObserver.observe(root.querySelector('.sdk-content'));
 }
 window.addEventListener?.('resize',sizeBoard);
 window.requestAnimationFrame?.(sizeBoard);
 window.meviSudokuTimer=setInterval(()=>{
  if(root&&game&&!game.finished){
   const t=root.querySelector('#sdk-time');if(t)t.textContent=time();
  }
 },1000);
}
function unmount(){
 boardObserver?.disconnect();boardObserver=null;
 window.removeEventListener?.('resize',sizeBoard);
 if(window.meviSudokuTimer){clearInterval(window.meviSudokuTimer);window.meviSudokuTimer=null}
 document.removeEventListener('keydown',onKey);
 if(root)root.removeEventListener('click',onClick);
 root=null;
}
window.meviSudokuHTML=()=>'<div class="sdk-host"></div>';window.meviSudokuMount=mount;window.meviSudokuUnmount=unmount;
})();