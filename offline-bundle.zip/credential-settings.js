/* Central configuration UI. Never embed entered secrets into HTML or logs.
   Browser API keys / OAuth client identifiers retain their legacy local keys for compatibility.
   HA token is persisted only in the standalone Web browser, scoped to the HA origin.
   Android keeps its existing native Keystore flow. The MeviTV PIN uses Android
   Keystore when supported by the APK, otherwise localStorage. */
(function(global){
'use strict';
const MAPS_KEY='mevicar-next-google-maps-key-v1';
const SPOTIFY_KEY='mevicar-spotify-client-v1';
const CAL_KEY='mevicar-next-calendar-settings-v1';
const ROAD_KEY='mevicar-next-roadassist-v1';
const TV_PIN_KEY='mevicar-next-tv-pin-v1';
const HA_WEB_TOKEN_KEY='mevicar-next-ha-web-token-v1';
let tvPin='', feedback='', nativeStatus=null, requestNumber=0;
let tvPinLoad=null,nativePinAvailable=false;
const pending=new Map();
const escapeHTML=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
function saved(key){try{return localStorage.getItem(key)||''}catch{return ''}}
// The PIN is read only on this origin/device; it is never rendered in HTML or logs.
{const storedPin=saved(TV_PIN_KEY);if(/^\d{4}$/.test(storedPin))tvPin=storedPin;}
function json(key){try{return JSON.parse(saved(key)||'{}')}catch{return {}}}
function input(id){return document.getElementById('mevi-cred-'+id)}
function value(id){return String(input(id)?.value||'').trim()}
function clearInput(id){const field=input(id);if(field)field.value=''}
function report(s){feedback=String(s||'').slice(0,220);const e=document.getElementById('mevi-credentials-feedback');if(e)e.textContent=feedback}
function row(id,title,placeholder,status,description,options={}){
 const type=options.secret?'password':'text';
 const inputmode=options.pin?' inputmode="numeric" maxlength="4" pattern="[0-9]{4}"':'';
 return '<div class="mevi-cred-row"><label for="mevi-cred-'+id+'">'+escapeHTML(title)+'</label>'+
  '<div class="mevi-cred-form"><input id="mevi-cred-'+id+'" type="'+type+'"'+inputmode+
  ' autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="'+escapeHTML(placeholder)+'">'+
  '<button type="button" onclick="MeviCredentials.save(\''+id+'\')">Speichern</button>'+
  '<button type="button" class="mevi-cred-remove" onclick="MeviCredentials.clear(\''+id+'\')">Entfernen</button></div>'+
  '<small class="mevi-cred-status">'+escapeHTML(status)+'</small><p>'+escapeHTML(description)+'</p></div>';
}
function nativeAvailable(){return !!(global.MeviNativeBridge?.postMessage || global.Capacitor?.Plugins?.MeviSecureSettings)}
// This opt-in is Web-only: do not copy an Android Keystore secret into localStorage.
function webHaRecord(){
 if(nativeAvailable())return null;
 try{
  const record=JSON.parse(localStorage.getItem(HA_WEB_TOKEN_KEY)||'null');
  if(!record||typeof record.origin!=='string'||typeof record.token!=='string'||
      record.token.length<20||/\s/.test(record.token))return null;
  return record;
 }catch{return null}
}
async function restoreWebHaToken(){
 const record=webHaRecord();
 const ha=global.MeviHA;
 if(!record||!ha?.debug||!ha?.connectWithToken)return false;
 // Never send a saved bearer token to a different HA installation.
 if(record.origin!==ha.debug().origin)return false;
 if(ha.debug().connected)return true;
 try{
  await ha.connectWithToken(record.token);
  return !!ha.debug().connected;
 }catch(e){
  // Offline and CORS failures must not erase the saved token.
  if(/HTTP 40[13]\b/.test(String(e?.message||e))){
   try{localStorage.removeItem(HA_WEB_TOKEN_KEY)}catch{}
  }
  return false;
 }
}
if(typeof global.addEventListener==='function'){
 global.addEventListener('load',()=>{void restoreWebHaToken()});
}
function nativeCall(action,name,secret){
 const plugin=global.Capacitor?.Plugins?.MeviSecureSettings;
 if(plugin){
  if(action==='settings.status')return plugin.status();
  if(action==='settings.get')return plugin.get?.({name})||Promise.reject(new Error('Android-PIN-Abruf nicht verfügbar.'));
  if(action==='settings.set')return plugin.set({name,value:secret});
  if(action==='settings.clear')return plugin.remove({name});
  return Promise.reject(new Error('Android-Einstellung unbekannt.'));
 }
 return new Promise((resolve,reject)=>{
  if(!nativeAvailable())return reject(new Error('Nur in der Android-APK verfügbar.'));
  const id='settings-'+(++requestNumber);
  const timer=setTimeout(()=>{pending.delete(id);reject(new Error('Keine Antwort der Android-App.'))},8000);
  pending.set(id,{resolve,reject,timer});
  try{global.MeviNativeBridge.postMessage(JSON.stringify({id,action,name,value:secret}))}
  catch(e){clearTimeout(timer);pending.delete(id);reject(new Error('Android-Schnittstelle nicht verfügbar.'))}
 });
}
function onNativeMessage(event){
 let data;try{data=JSON.parse(event.data)}catch{return}
 const item=pending.get(data.id);if(!item)return;
 pending.delete(data.id);clearTimeout(item.timer);
 if(data.ok)item.resolve(data);else item.reject(new Error(data.error||'Einstellung nicht gespeichert.'));
}
// Chain instead of overwrite: Spotify and update replies share this single bridge handler.
if(global.MeviNativeBridge){const previousNativeHandler=global.MeviNativeBridge.onmessage;global.MeviNativeBridge.onmessage=event=>{if(typeof previousNativeHandler==='function'){try{previousNativeHandler(event)}catch{}}onNativeMessage(event)}}
// Restore from the encrypted APK vault after WebView navigation, with automatic
// migration of an old localStorage PIN on the first updated APK launch.
function tvPinReady(){
 if(!nativeAvailable())return Promise.resolve(tvPin);
 if(tvPinLoad)return tvPinLoad;
 tvPinLoad=nativeCall('settings.get','tvPin').then(async response=>{
  const securePin=String(response?.value||'');
  nativePinAvailable=true;
  if(/^\d{4}$/.test(securePin))tvPin=securePin;
  else if(/^\d{4}$/.test(tvPin))await nativeCall('settings.set','tvPin',tvPin);
  try{localStorage.removeItem(TV_PIN_KEY)}catch{}
  return tvPin;
 }).catch(()=>tvPin);
 return tvPinLoad;
}
if(nativeAvailable())void tvPinReady();
function html(){
 const ha=global.MeviHA?.debug?.()||{};
 const cal=json(CAL_KEY),road=json(ROAD_KEY);
 const android=nativeAvailable();
 const haSaved=!android&&!!webHaRecord();
 const groups=[
  '<h3>Google-Dienste</h3>',
  ...(android?[
   row('android-maps','Google Navigation SDK · Android-API-Key','Android-SDK-Schlüssel eingeben',
       nativeStatus?.mapsKey?'Verschlüsselt auf dem Gerät gespeichert':'Status auf dem Gerät prüfen',
       'Für Android-Karte, Google-Places-Adresssuche und Routenführung. Paket de.mevicar.next und SHA-1 der signierten APK in Google Cloud freigeben.',{secret:true})
  ]:[
   row('maps','Google Maps · Browser-API-Key','Neuen Browser-API-Key eingeben',
       saved(MAPS_KEY)?'Eingerichtet':'Nicht eingerichtet',
       'Nur für die Web-App: HTTP-Referrer auf die MeviCar-Seite einschränken. Kein Android-SDK-Schlüssel.')
  ]),
  row('calendar','Google Kalender · OAuth-Web-Client-ID','…apps.googleusercontent.com',
      cal.clientId?'Eingerichtet':'Nicht eingerichtet',
      'Client-ID für den lesenden Kalenderzugriff; Google-Passwort wird niemals hier eingegeben.'),
  '<h3>Medien und Blitzer</h3>',
  row('spotify','Spotify · Client-ID','Neue Spotify Client-ID eingeben',
      saved(SPOTIFY_KEY)?'Eingerichtet':'Nicht eingerichtet',
      'OAuth PKCE: kein Client Secret oder Spotify-Passwort erforderlich.'),
  row('road','Blitzer.de · HA-Konfigurations-ID','26-stellige Config Entry ID',
      road.configId?'Eingerichtet':'Nicht eingerichtet',
      'Steuert den optionalen Routenscan; kein Home-Assistant-Token.'),
  row('tv','MeviTV · vierstelliger PIN','Vierstelligen Zugangscode eingeben',
      tvPin?(nativePinAvailable?'Verschlüsselt in der APK gespeichert':'Auf diesem Gerät gespeichert'):'Nicht hinterlegt',
      android?'Die neue Android-APK speichert die PIN verschlüsselt. Bei älteren APK-Versionen kann die PIN im WebView-Speicher liegen.':'Der PIN bleibt auf diesem Gerät im Browser-Speicher; dort ist er nicht verschlüsselt.',{secret:true,pin:true}),
  '<h3>Home Assistant</h3>',
  row('ha','Home Assistant · Long-Lived Access Token','Neuen HA-Token einfügen',
      ha.connected?(haSaved?'API verbunden · im Browser gespeichert':'API verbunden'):haSaved?'Im Browser gespeichert · nicht verbunden':ha.tokenPresent?'Token in dieser Sitzung vorhanden':'Nicht verbunden',
      android?'Die Android-APK nutzt ihren bisherigen geschützten Gerätespeicher.':'Der Token bleibt nach einem Neustart in diesem Browser gespeichert (nicht verschlüsselt). Nur auf einem privaten PC verwenden; mit „Entfernen“ wieder löschen.',{secret:true}),
  '<div class="mevi-cred-row"><label for="mevi-cred-ha-origin">Home Assistant · HTTPS-Adresse</label>'+
  '<div class="mevi-cred-form"><input id="mevi-cred-ha-origin" type="url" spellcheck="false" value="'+escapeHTML(ha.origin||'')+'" placeholder="https://homeassistant.example">'+
  '<button type="button" onclick="MeviCredentials.save(\'ha-origin\')">Adresse speichern</button></div>'+
  '<label for="mevi-cred-ha-path">Dashboard-Pfad</label><input id="mevi-cred-ha-path" type="text" spellcheck="false" value="'+escapeHTML(ha.dashboard?.replace(ha.origin||'','')||'/')+'">'+
  '<p>API und Dashboard verwenden dieselbe gespeicherte HTTPS-Basisadresse. Für die Browser-API muss Home Assistant die CORS-Herkunft erlauben.</p></div>'
 ];
 if(android){
  groups.push('<h3>Nur Android-APK</h3>');
  groups.push(row('github-token','GitHub · Token für private APK-Updates','GitHub Fine-grained PAT eingeben',
    nativeStatus?.githubToken?'Verschlüsselt auf dem Gerät gespeichert':'Status auf dem Gerät prüfen',
    'Nur Zugriff auf eskiya771/mevicar-next · Contents: Read-only. Der Token wird ausschließlich im Android Keystore gespeichert.',{secret:true}));
  groups.push('<button type="button" onclick="MeviCredentials.refreshNativeStatus()">Gespeicherte Android-Zugänge prüfen</button>');
 }else{
  groups.push('<p class="mevi-cred-note">Der Android-Navigation-SDK-Schlüssel wird ausschließlich in Settings der APK eingegeben, nicht im Browser.</p>');
 }
 return '<div class="mevi-credentials"><p class="mevi-cred-intro">Alle Schlüssel, Client-IDs, PINs und Zugänge werden hier verwaltet. Die übrigen Apps haben keine eigenen Zugangsdatenfelder mehr.</p>'+
  groups.join('')+
  '<p class="mevi-cred-note">'+(android?
   'Android: Google-Navigation und Places verwenden ausschließlich den Android-API-Key im verschlüsselten Android Keystore; ein Browser-Key wird nicht benötigt.':
   'Web-App: Google Maps nutzt einen auf diese Website eingeschränkten Browser-API-Key.')+
   ' Der MeviTV-PIN wird in der aktuellen Android-APK verschlüsselt, in der Web-App lokal gespeichert. '+
   (android?'Die Android-APK verwaltet HA-Zugänge weiterhin separat.':'Der HA-Token wird lokal und unverschlüsselt in diesem Browser gespeichert, nicht auf GitHub.')+'</p>'+
  '<div id="mevi-credentials-feedback" role="status" aria-live="polite">'+escapeHTML(feedback)+'</div></div>';
}
async function save(id){
 const v=value(id);
 try {
  switch(id){
   case 'maps':
    if(nativeAvailable())throw new Error('Der Browser-Key ist in der APK nicht verfügbar. Bitte den Android-Navigation-Key verwenden.');
    if(!/^[A-Za-z0-9_-]{20,}$/.test(v))throw new Error('Google Maps Browser-Key ist ungültig.');
    localStorage.setItem(MAPS_KEY,v);break;
   case 'spotify':
    if(!/^[A-Za-z0-9]{8,64}$/.test(v))throw new Error('Spotify Client-ID ist ungültig.');
    global.meviSpotifySaveClient?.(v);break;
   case 'calendar':
    if(!global.MeviCalendar?.setClientId?.(v))throw new Error('Google OAuth-Client-ID ist ungültig.');break;
   case 'road':
    if(!global.MeviRoadAssist?.setConfigId?.(v))throw new Error('Blitzer Konfigurations-ID ist ungültig.');break;
   case 'tv':
    if(!/^\d{4}$/.test(v))throw new Error('PIN muss aus genau vier Ziffern bestehen.');
    await tvPinReady();
    if(nativePinAvailable){
     await nativeCall('settings.set','tvPin',v);
     try{localStorage.removeItem(TV_PIN_KEY)}catch{}
    }else{
     // Web or legacy APK: do not claim success unless persistence is verified.
     localStorage.setItem(TV_PIN_KEY,v);
     if(saved(TV_PIN_KEY)!==v)throw new Error('Die PIN konnte nicht dauerhaft gespeichert werden.');
    }
    tvPin=v;break;
   case 'ha':
    if(v.length<20||/\s/.test(v))throw new Error('Bitte einen gültigen Home-Assistant-Token eingeben.');
    await global.MeviHA?.connectWithToken?.(v);
    if(!global.MeviHA?.debug?.().connected)throw new Error('HA-Verbindung fehlgeschlagen. URL, Token und CORS prüfen.');
    if(nativeAvailable())await nativeCall('settings.set','haToken',v).catch(()=>null);
    else{
     const origin=global.MeviHA.debug().origin;
     if(typeof origin!=='string'||!origin.startsWith('https://'))throw new Error('Ungültige Home-Assistant-Adresse.');
     const record=JSON.stringify({origin,token:v});
     localStorage.setItem(HA_WEB_TOKEN_KEY,record);
     if(localStorage.getItem(HA_WEB_TOKEN_KEY)!==record)throw new Error('Der HA-Token konnte nicht dauerhaft gespeichert werden.');
    }
    break;
   case 'ha-origin':{
    const origin=value('ha-origin'),path=value('ha-path');
    const previousOrigin=global.MeviHA?.debug?.().origin;
    global.MeviHA?.configureEndpoint(origin,path);
    // An old token must never be replayed after changing the server address.
    if(!nativeAvailable()&&previousOrigin!==global.MeviHA?.debug?.().origin){
     localStorage.removeItem(HA_WEB_TOKEN_KEY);
    }
    break;
   }
   case 'android-maps':
    if(!/^[A-Za-z0-9_-]{20,}$/.test(v))throw new Error('Android-Navigation-API-Key ist ungültig.');
    await nativeCall('settings.set','mapsKey',v);
    nativeStatus={...nativeStatus,mapsKey:true};break;
   case 'github-token':
    if(v.length<20||v.length>8192||/\s/.test(v))throw new Error('GitHub-Token ist ungültig.');
    await nativeCall('settings.set','githubToken',v);
    nativeStatus={...nativeStatus,githubToken:true};break;
   default:throw new Error('Einstellung nicht bekannt.');
  }
  clearInput(id);report('Einstellung gespeichert.'); 
  if(id==='maps'){global.location.reload();return}
  if(id==='ha-origin'){const d=document.getElementById('mevi-cred-ha-path');if(d)d.blur()}
  global.render?.();
 }catch(e){report(e.message||'Speichern fehlgeschlagen.')}
}
async function clear(id){
 try{
  switch(id){
   case 'maps':
    if(nativeAvailable())throw new Error('In der APK ist nur der Android-Navigation-Key verfügbar.');
    localStorage.removeItem(MAPS_KEY);break;
   case 'spotify':global.meviSpotifyResetClient?.(true);break;
   case 'calendar':global.MeviCalendar?.setClientId?.('');break;
   case 'road':global.MeviRoadAssist?.setConfigId?.('');break;
   case 'tv':
    await tvPinReady();
    if(nativePinAvailable)await nativeCall('settings.clear','tvPin');
    localStorage.removeItem(TV_PIN_KEY);tvPin='';break;
   case 'ha':
    global.MeviHA?.disconnect?.();
    // Clear any browser copy even when an old hybrid had used the same WebView origin.
    localStorage.removeItem(HA_WEB_TOKEN_KEY);
    if(nativeAvailable())await nativeCall('settings.clear','haToken').catch(()=>null);
    break;
   case 'android-maps':await nativeCall('settings.clear','mapsKey');nativeStatus={...nativeStatus,mapsKey:false};break;
   case 'github-token':await nativeCall('settings.clear','githubToken');nativeStatus={...nativeStatus,githubToken:false};break;
   default:throw new Error('Einstellung nicht bekannt.');
  }
  clearInput(id);report('Einstellung entfernt.');
  if(id==='maps'){global.location.reload();return}
  global.render?.();
 }catch(e){report(e.message||'Entfernen fehlgeschlagen.')}
}
async function refreshNativeStatus(){
 try{const d=await nativeCall('settings.status');nativeStatus=d.configured||{};report('Android-Speicherstatus aktualisiert.');global.render?.()}
 catch(e){report(e.message)}
}
global.MeviCredentials={html,save,clear,tvPin:()=>tvPin,tvPinReady,refreshNativeStatus,nativeAvailable,onNativeMessage};

})(typeof window==='undefined'?globalThis:window);
